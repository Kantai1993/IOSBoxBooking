//
//  iLogicBoxBooking.h
//  iLogicBoxBooking
//
//  Created by YenPhan on 9/17/19.
//  Copyright © 2019 YenPhan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for iLogicBoxBooking.
FOUNDATION_EXPORT double iLogicBoxBookingVersionNumber;

//! Project version string for iLogicBoxBooking.
FOUNDATION_EXPORT const unsigned char iLogicBoxBookingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iLogicBoxBooking/PublicHeader.h>


